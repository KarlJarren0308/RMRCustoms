<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-menus">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="./" class="navbar-brand"><img style="display: inline-block; vertical-align: middle; height: 100%;" src="assets/img/logo.png">&nbsp;RMR Customs Brokerage Corporation</a>
        </div>
        <div id="navbar-menus" class="navbar-right collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li><a href="about.php">About Us</a></li>
                <li><a href="track.php">Track Delivery</a></li>
                <li><a href="./admin">Admin Login</a></li>
            </ul>
        </div>
    </div>
</nav>