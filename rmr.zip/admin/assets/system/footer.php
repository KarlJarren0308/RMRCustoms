<noscript>
    <div class="overlay">
        <div class="overlay">
            <div class="overlay">
                <div class="overlay-block">
                    <div class="overlay-title">Oops! JavaScript was blocked on this page</div>
                    <div class="overlay-body">
                        <p>We're sorry, but this page won't work properly without JavaScript enabled. Please allow this page to run JavaScript and then reload the page.</p>
                        <div class="text-right">
                            <a href="" class="btn btn-primary btn-sm">Reload Page</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</noscript>
</body>
</html>