# RMRCustoms

Online Web-based Billing System with Global Positioning System for RMR Customs Brokerage Corporation.

© Copyright 2015 [Karl T. Macadangdang](https://github.com/KarlJarren0308)
